import React from 'react';
import LoginScreen from './LoginScreen';

export default function App() {
  return (
    <LoginScreen />
  );
}