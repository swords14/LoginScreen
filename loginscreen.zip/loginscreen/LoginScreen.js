import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Modal, Linking, KeyboardAvoidingView, TouchableWithoutFeedback, Keyboard, Platform, Image } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import {
  FacebookLoginButton,
  GoogleLoginButton,
  InstagramLoginButton,
  AppleLoginButton,
} from "react-social-login-buttons";

const AppHeader = () => {
  return (
    <View style={styles.header}>
      <Image source={{ uri: 'https://i.imgur.com/qLuqZIa.png' }} style={styles.logo} />
    </View>
  );
};

const LoginScreen = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [modalVisible, setModalVisible] = useState(false);

  const handleLogin = () => {
    if (email.trim() === 'user@example.com' && password === 'password') {
      Alert.alert('Login bem-sucedido', 'Bem-vindo de volta!');
    } else {
      Alert.alert('Erro de Login', 'Credenciais inválidas. Por favor, tente novamente.');
    }
  };

  const handleFacebookLogin = () => {
    // Lógica de autenticação com Facebook
  };

  const handleGoogleLogin = () => {
    // Lógica de autenticação com Google
  };

  const handleInstagramLogin = () => {
    // Lógica de autenticação com Instagram
  };

  const handleAppleLogin = () => {
    // Lógica de autenticação com Apple
  };

  const openEmailApp = () => {
    Linking.openURL('mailto:suporte@exemplo.com?subject=Relatar Problema Técnico&body=Descreva o problema aqui...');
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior="padding">
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.inner}>
          <AppHeader />
          <TextInput
            style={styles.input}
            placeholder="Email"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
          />
          <TextInput
            style={styles.input}
            placeholder="Senha"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
          <View style={styles.buttonContainer}>
            <FacebookLoginButton onClick={handleFacebookLogin} />
            <GoogleLoginButton onClick={handleGoogleLogin} />
            <InstagramLoginButton onClick={handleInstagramLogin} />
            <AppleLoginButton onClick={handleAppleLogin} />
          </View>
          <TouchableOpacity style={styles.helpButton} onPress={() => setModalVisible(true)}>
      <MaterialIcons name="help" size={24} color="#FF6347" />
      <Text style={styles.helpButtonText}> Precisa de Ajuda? </Text>
       </TouchableOpacity>
        </View>
      </TouchableWithoutFeedback>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(false);
        }}
      >
        <View style={styles.modalContainer}>
          <Text style={styles.modalText}>Precisa de Ajuda?</Text>
          <Text style={styles.modalInstructions}>
            Entre em contato conosco para obter suporte técnico.
          </Text>
          <TouchableOpacity style={styles.modalButton} onPress={openEmailApp}>
            <Text style={styles.modalButtonText}>Contatar Suporte</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.closeButton} onPress={() => setModalVisible(false)}>
            <Text style={styles.closeButtonText}>Fechar</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'fff',
    paddingHorizontal: 20,
  },
  inner: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    width: '80%',
    height: 50,
    borderWidth: 1,
    borderColor: '#FF6347',
    borderRadius: 10,
    paddingHorizontal: 15,
    marginBottom: 15,
    backgroundColor: '#FFFFFF',
    color: '#333333',
  },
  buttonContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginVertical: 10,
  },
  helpButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  helpButtonText: {
    color: '#FF6347',
    marginLeft: 5,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    padding: 10,
  },
  logo: {
    width: 160,
    height: 145,
  },
});


export default LoginScreen;